const client_manifest = {
  "_icons.12ddecaf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "icons.c8f8ec3a.css"
    ],
    "file": "icons.12ddecaf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "icons.c8f8ec3a.css": {
    "file": "icons.c8f8ec3a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.39a2b2de.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.39a2b2de.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vue.f36acd1f.b3408f36.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.b3408f36.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/styles/font/MuseoSansCyrl-100.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "MuseoSansCyrl-100.54075098.ttf",
    "src": "assets/styles/font/MuseoSansCyrl-100.ttf"
  },
  "assets/styles/font/MuseoSansCyrl-500.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "MuseoSansCyrl-500.9f623d8a.ttf",
    "src": "assets/styles/font/MuseoSansCyrl-500.ttf"
  },
  "icons.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "icons.c8f8ec3a.css",
    "src": "icons.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.9ce73be1.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.e1e073a6.js",
    "imports": [
      "_nuxt-link.39a2b2de.js",
      "_icons.12ddecaf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.9ce73be1.css": {
    "file": "default.9ce73be1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.a38575fa.js",
    "imports": [
      "_nuxt-link.39a2b2de.js",
      "_vue.f36acd1f.b3408f36.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.047ab08a.js",
    "imports": [
      "_vue.f36acd1f.b3408f36.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.542cee6f.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.298d061e.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.f837eb36.js",
    "imports": [
      "_vue.f36acd1f.b3408f36.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_icons.12ddecaf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.298d061e.css": {
    "file": "index.298d061e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
