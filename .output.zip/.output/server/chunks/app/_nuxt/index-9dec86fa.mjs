import { u as useHead } from './index-6a088328.mjs';
import { _ as _export_sfc, u as useNuxtApp, a as useRuntimeConfig } from '../server.mjs';
import { defineComponent, ref, computed, h, useSSRContext, mergeProps, unref } from 'vue';
import { r as encodeParam, l as hasProtocol, t as withLeadingSlash, j as joinURL, p as parseURL, n as defu, v as encodePath } from '../../nitro/node-server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { _ as __nuxt_component_1$4 } from './icons-addfcaba.mjs';
import '@unhead/shared';
import 'unhead';
import 'vue-router';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';

async function imageMeta(_ctx, url) {
  const meta = await _imageMeta(url).catch((err) => {
    console.error("Failed to get image meta for " + url, err + "");
    return {
      width: 0,
      height: 0,
      ratio: 0
    };
  });
  return meta;
}
async function _imageMeta(url) {
  {
    const imageMeta2 = await import('image-meta').then((r) => r.imageMeta);
    const data = await fetch(url).then((res) => res.buffer());
    const metadata = imageMeta2(data);
    if (!metadata) {
      throw new Error(`No metadata could be extracted from the image \`${url}\`.`);
    }
    const { width, height } = metadata;
    const meta = {
      width,
      height,
      ratio: width && height ? width / height : void 0
    };
    return meta;
  }
}
function createMapper(map) {
  return (key) => {
    return key ? map[key] || key : map.missingValue;
  };
}
function createOperationsGenerator({ formatter, keyMap, joinWith = "/", valueMap } = {}) {
  if (!formatter) {
    formatter = (key, value) => `${key}=${value}`;
  }
  if (keyMap && typeof keyMap !== "function") {
    keyMap = createMapper(keyMap);
  }
  const map = valueMap || {};
  Object.keys(map).forEach((valueKey) => {
    if (typeof map[valueKey] !== "function") {
      map[valueKey] = createMapper(map[valueKey]);
    }
  });
  return (modifiers = {}) => {
    const operations = Object.entries(modifiers).filter(([_, value]) => typeof value !== "undefined").map(([key, value]) => {
      const mapper = map[key];
      if (typeof mapper === "function") {
        value = mapper(modifiers[key]);
      }
      key = typeof keyMap === "function" ? keyMap(key) : key;
      return formatter(key, value);
    });
    return operations.join(joinWith);
  };
}
function parseSize(input = "") {
  if (typeof input === "number") {
    return input;
  }
  if (typeof input === "string") {
    if (input.replace("px", "").match(/^\d+$/g)) {
      return parseInt(input, 10);
    }
  }
}
function parseDensities(input = "") {
  if (input === void 0 || !input.length) {
    return [];
  }
  const densities = /* @__PURE__ */ new Set();
  for (const density of input.split(" ")) {
    const d = parseInt(density.replace("x", ""));
    if (d) {
      densities.add(d);
    }
  }
  return Array.from(densities);
}
function checkDensities(densities) {
  if (densities.length === 0) {
    throw new Error("`densities` must not be empty, configure to `1` to render regular size only (DPR 1.0)");
  }
}
function parseSizes(input) {
  const sizes = {};
  if (typeof input === "string") {
    for (const entry of input.split(/[\s,]+/).filter((e) => e)) {
      const s = entry.split(":");
      if (s.length !== 2) {
        sizes["1px"] = s[0].trim();
      } else {
        sizes[s[0].trim()] = s[1].trim();
      }
    }
  } else {
    Object.assign(sizes, input);
  }
  return sizes;
}
function createImage(globalOptions) {
  const ctx = {
    options: globalOptions
  };
  const getImage2 = (input, options = {}) => {
    const image = resolveImage(ctx, input, options);
    return image;
  };
  const $img = (input, modifiers = {}, options = {}) => {
    return getImage2(input, {
      ...options,
      modifiers: defu(modifiers, options.modifiers || {})
    }).url;
  };
  for (const presetName in globalOptions.presets) {
    $img[presetName] = (source, modifiers, options) => $img(source, modifiers, { ...globalOptions.presets[presetName], ...options });
  }
  $img.options = globalOptions;
  $img.getImage = getImage2;
  $img.getMeta = (input, options) => getMeta(ctx, input, options);
  $img.getSizes = (input, options) => getSizes(ctx, input, options);
  ctx.$img = $img;
  return $img;
}
async function getMeta(ctx, input, options) {
  const image = resolveImage(ctx, input, { ...options });
  if (typeof image.getMeta === "function") {
    return await image.getMeta();
  } else {
    return await imageMeta(ctx, image.url);
  }
}
function resolveImage(ctx, input, options) {
  var _a, _b;
  if (typeof input !== "string" || input === "") {
    throw new TypeError(`input must be a string (received ${typeof input}: ${JSON.stringify(input)})`);
  }
  if (input.startsWith("data:")) {
    return {
      url: input
    };
  }
  const { provider, defaults } = getProvider(ctx, options.provider || ctx.options.provider);
  const preset = getPreset(ctx, options.preset);
  input = hasProtocol(input) ? input : withLeadingSlash(input);
  if (!provider.supportsAlias) {
    for (const base in ctx.options.alias) {
      if (input.startsWith(base)) {
        input = joinURL(ctx.options.alias[base], input.substr(base.length));
      }
    }
  }
  if (provider.validateDomains && hasProtocol(input)) {
    const inputHost = parseURL(input).host;
    if (!ctx.options.domains.find((d) => d === inputHost)) {
      return {
        url: input
      };
    }
  }
  const _options = defu(options, preset, defaults);
  _options.modifiers = { ..._options.modifiers };
  const expectedFormat = _options.modifiers.format;
  if ((_a = _options.modifiers) == null ? void 0 : _a.width) {
    _options.modifiers.width = parseSize(_options.modifiers.width);
  }
  if ((_b = _options.modifiers) == null ? void 0 : _b.height) {
    _options.modifiers.height = parseSize(_options.modifiers.height);
  }
  const image = provider.getImage(input, _options, ctx);
  image.format = image.format || expectedFormat || "";
  return image;
}
function getProvider(ctx, name) {
  const provider = ctx.options.providers[name];
  if (!provider) {
    throw new Error("Unknown provider: " + name);
  }
  return provider;
}
function getPreset(ctx, name) {
  if (!name) {
    return {};
  }
  if (!ctx.options.presets[name]) {
    throw new Error("Unknown preset: " + name);
  }
  return ctx.options.presets[name];
}
function getSizes(ctx, input, opts) {
  var _a, _b, _c, _d, _e;
  const width = parseSize((_a = opts.modifiers) == null ? void 0 : _a.width);
  const height = parseSize((_b = opts.modifiers) == null ? void 0 : _b.height);
  const sizes = parseSizes(opts.sizes);
  const densities = ((_c = opts.densities) == null ? void 0 : _c.trim()) ? parseDensities(opts.densities.trim()) : ctx.options.densities;
  checkDensities(densities);
  const hwRatio = width && height ? height / width : 0;
  const sizeVariants = [];
  const srcsetVariants = [];
  if (Object.keys(sizes).length >= 1) {
    for (const key in sizes) {
      const variant = getSizesVariant(key, String(sizes[key]), height, hwRatio, ctx);
      if (variant === void 0) {
        continue;
      }
      sizeVariants.push({
        size: variant.size,
        screenMaxWidth: variant.screenMaxWidth,
        media: `(max-width: ${variant.screenMaxWidth}px)`
      });
      for (const density of densities) {
        srcsetVariants.push({
          width: variant._cWidth * density,
          src: getVariantSrc(ctx, input, opts, variant, density)
        });
      }
    }
    finaliseSizeVariants(sizeVariants);
  } else {
    for (const density of densities) {
      const key = Object.keys(sizes)[0];
      let variant = getSizesVariant(key, String(sizes[key]), height, hwRatio, ctx);
      if (variant === void 0) {
        variant = {
          size: "",
          screenMaxWidth: 0,
          _cWidth: (_d = opts.modifiers) == null ? void 0 : _d.width,
          _cHeight: (_e = opts.modifiers) == null ? void 0 : _e.height
        };
      }
      srcsetVariants.push({
        width: density,
        src: getVariantSrc(ctx, input, opts, variant, density)
      });
    }
  }
  finaliseSrcsetVariants(srcsetVariants);
  const defaultVariant = srcsetVariants[srcsetVariants.length - 1];
  const sizesVal = sizeVariants.length ? sizeVariants.map((v) => `${v.media ? v.media + " " : ""}${v.size}`).join(", ") : void 0;
  const suffix = sizesVal ? "w" : "x";
  const srcsetVal = srcsetVariants.map((v) => `${v.src} ${v.width}${suffix}`).join(", ");
  return {
    sizes: sizesVal,
    srcset: srcsetVal,
    src: defaultVariant == null ? void 0 : defaultVariant.src
  };
}
function getSizesVariant(key, size, height, hwRatio, ctx) {
  const screenMaxWidth = ctx.options.screens && ctx.options.screens[key] || parseInt(key);
  const isFluid = size.endsWith("vw");
  if (!isFluid && /^\d+$/.test(size)) {
    size = size + "px";
  }
  if (!isFluid && !size.endsWith("px")) {
    return void 0;
  }
  let _cWidth = parseInt(size);
  if (!screenMaxWidth || !_cWidth) {
    return void 0;
  }
  if (isFluid) {
    _cWidth = Math.round(_cWidth / 100 * screenMaxWidth);
  }
  const _cHeight = hwRatio ? Math.round(_cWidth * hwRatio) : height;
  return {
    size,
    screenMaxWidth,
    _cWidth,
    _cHeight
  };
}
function getVariantSrc(ctx, input, opts, variant, density) {
  return ctx.$img(
    input,
    {
      ...opts.modifiers,
      width: variant._cWidth ? variant._cWidth * density : void 0,
      height: variant._cHeight ? variant._cHeight * density : void 0
    },
    opts
  );
}
function finaliseSizeVariants(sizeVariants) {
  var _a;
  sizeVariants.sort((v1, v2) => v1.screenMaxWidth - v2.screenMaxWidth);
  let previousMedia = null;
  for (let i = sizeVariants.length - 1; i >= 0; i--) {
    const sizeVariant = sizeVariants[i];
    if (sizeVariant.media === previousMedia) {
      sizeVariants.splice(i, 1);
    }
    previousMedia = sizeVariant.media;
  }
  for (let i = 0; i < sizeVariants.length; i++) {
    sizeVariants[i].media = ((_a = sizeVariants[i + 1]) == null ? void 0 : _a.media) || "";
  }
}
function finaliseSrcsetVariants(srcsetVariants) {
  srcsetVariants.sort((v1, v2) => v1.width - v2.width);
  let previousWidth = null;
  for (let i = srcsetVariants.length - 1; i >= 0; i--) {
    const sizeVariant = srcsetVariants[i];
    if (sizeVariant.width === previousWidth) {
      srcsetVariants.splice(i, 1);
    }
    previousWidth = sizeVariant.width;
  }
}
const operationsGenerator = createOperationsGenerator({
  keyMap: {
    format: "f",
    fit: "fit",
    width: "w",
    height: "h",
    resize: "s",
    quality: "q",
    background: "b"
  },
  joinWith: "&",
  formatter: (key, val) => encodeParam(key) + "_" + encodeParam(val)
});
const getImage = (src, { modifiers = {}, baseURL } = {}, ctx) => {
  if (modifiers.width && modifiers.height) {
    modifiers.resize = `${modifiers.width}x${modifiers.height}`;
    delete modifiers.width;
    delete modifiers.height;
  }
  const params = operationsGenerator(modifiers) || "_";
  if (!baseURL) {
    baseURL = joinURL(ctx.options.nuxt.baseURL, "/_ipx");
  }
  return {
    url: joinURL(baseURL, params, encodePath(src))
  };
};
const validateDomains = true;
const supportsAlias = true;
const ipxRuntime$HoGvELzMtH = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  getImage,
  supportsAlias,
  validateDomains
});
const imageOptions = {
  "screens": {
    "xs": 320,
    "sm": 640,
    "md": 768,
    "lg": 1024,
    "xl": 1280,
    "xxl": 1536,
    "2xl": 1536
  },
  "presets": {},
  "provider": "ipx",
  "domains": [],
  "alias": {},
  "densities": [
    1,
    2
  ],
  "format": [
    "webp"
  ]
};
imageOptions.providers = {
  ["ipx"]: { provider: ipxRuntime$HoGvELzMtH, defaults: {} }
};
const useImage = () => {
  const config = useRuntimeConfig();
  const nuxtApp = useNuxtApp();
  return nuxtApp.$img || nuxtApp._img || (nuxtApp._img = createImage({
    ...imageOptions,
    nuxt: {
      baseURL: config.app.baseURL
    }
  }));
};
const baseImageProps = {
  // input source
  src: { type: String, required: true },
  // modifiers
  format: { type: String, default: void 0 },
  quality: { type: [Number, String], default: void 0 },
  background: { type: String, default: void 0 },
  fit: { type: String, default: void 0 },
  modifiers: { type: Object, default: void 0 },
  // options
  preset: { type: String, default: void 0 },
  provider: { type: String, default: void 0 },
  sizes: { type: [Object, String], default: void 0 },
  densities: { type: String, default: void 0 },
  preload: { type: Boolean, default: void 0 },
  // <img> attributes
  width: { type: [String, Number], default: void 0 },
  height: { type: [String, Number], default: void 0 },
  alt: { type: String, default: void 0 },
  referrerpolicy: { type: String, default: void 0 },
  usemap: { type: String, default: void 0 },
  longdesc: { type: String, default: void 0 },
  ismap: { type: Boolean, default: void 0 },
  loading: {
    type: String,
    default: void 0,
    validator: (val) => ["lazy", "eager"].includes(val)
  },
  crossorigin: {
    type: [Boolean, String],
    default: void 0,
    validator: (val) => ["anonymous", "use-credentials", "", true, false].includes(val)
  },
  decoding: {
    type: String,
    default: void 0,
    validator: (val) => ["async", "auto", "sync"].includes(val)
  },
  // csp
  nonce: { type: [String], default: void 0 }
};
const useBaseImage = (props) => {
  const options = computed(() => {
    return {
      provider: props.provider,
      preset: props.preset
    };
  });
  const attrs = computed(() => {
    return {
      width: parseSize(props.width),
      height: parseSize(props.height),
      alt: props.alt,
      referrerpolicy: props.referrerpolicy,
      usemap: props.usemap,
      longdesc: props.longdesc,
      ismap: props.ismap,
      crossorigin: props.crossorigin === true ? "anonymous" : props.crossorigin || void 0,
      loading: props.loading,
      decoding: props.decoding,
      nonce: props.nonce
    };
  });
  const $img = useImage();
  const modifiers = computed(() => {
    return {
      ...props.modifiers,
      width: parseSize(props.width),
      height: parseSize(props.height),
      format: props.format,
      quality: props.quality || $img.options.quality,
      background: props.background,
      fit: props.fit
    };
  });
  return {
    options,
    attrs,
    modifiers
  };
};
const imgProps = {
  ...baseImageProps,
  placeholder: { type: [Boolean, String, Number, Array], default: void 0 }
};
const __nuxt_component_1$3 = defineComponent({
  name: "NuxtImg",
  props: imgProps,
  emits: ["load", "error"],
  setup: (props, ctx) => {
    const $img = useImage();
    const _base = useBaseImage(props);
    const placeholderLoaded = ref(false);
    const sizes = computed(() => $img.getSizes(props.src, {
      ..._base.options.value,
      sizes: props.sizes,
      densities: props.densities,
      modifiers: {
        ..._base.modifiers.value,
        width: parseSize(props.width),
        height: parseSize(props.height)
      }
    }));
    const attrs = computed(() => {
      const attrs2 = { ..._base.attrs.value, "data-nuxt-img": "" };
      if (!props.placeholder || placeholderLoaded.value) {
        attrs2.sizes = sizes.value.sizes;
        attrs2.srcset = sizes.value.srcset;
      }
      return attrs2;
    });
    const placeholder = computed(() => {
      let placeholder2 = props.placeholder;
      if (placeholder2 === "") {
        placeholder2 = true;
      }
      if (!placeholder2 || placeholderLoaded.value) {
        return false;
      }
      if (typeof placeholder2 === "string") {
        return placeholder2;
      }
      const size = Array.isArray(placeholder2) ? placeholder2 : typeof placeholder2 === "number" ? [placeholder2, placeholder2] : [10, 10];
      return $img(props.src, {
        ..._base.modifiers.value,
        width: size[0],
        height: size[1],
        quality: size[2] || 50,
        blur: size[3] || 3
      }, _base.options.value);
    });
    const mainSrc = computed(
      () => props.sizes ? sizes.value.src : $img(props.src, _base.modifiers.value, _base.options.value)
    );
    const src = computed(() => placeholder.value ? placeholder.value : mainSrc.value);
    if (props.preload) {
      const isResponsive = Object.values(sizes.value).every((v) => v);
      useHead({
        link: [{
          rel: "preload",
          as: "image",
          nonce: props.nonce,
          ...!isResponsive ? { href: src.value } : {
            href: sizes.value.src,
            imagesizes: sizes.value.sizes,
            imagesrcset: sizes.value.srcset
          }
        }]
      });
    }
    const imgEl = ref();
    const nuxtApp = useNuxtApp();
    nuxtApp.isHydrating;
    return () => h("img", {
      ref: imgEl,
      src: src.value,
      ...{ onerror: "this.setAttribute('data-error', 1)" },
      ...attrs.value,
      ...ctx.attrs
    });
  }
});
const _sfc_main$d = {};
function _sfc_ssrRender$9(_ctx, _push, _parent, _attrs) {
  const _component_NuxtImg = __nuxt_component_1$3;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "offer" }, _attrs))} data-v-9d043aa4><div class="offer__title" data-v-9d043aa4><div class="title" data-v-9d043aa4><h1 data-v-9d043aa4>\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0438<br data-v-9d043aa4>\u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0441\u0430\u0439\u0442\u043E\u0432</h1><h2 data-v-9d043aa4>\u0421\u043E\u0437\u0434\u0430\u0451\u043C \u0441\u0430\u0439\u0442\u044B \u043F\u043E\u0434 \u043A\u043B\u044E\u0447. \u0420\u0430\u0441\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u0435\u043C \u0431\u044E\u0434\u0436\u0435\u0442 \u0434\u043B\u044F<br data-v-9d043aa4>\u043A\u0430\u0436\u0434\u043E\u0433\u043E \u043F\u0440\u043E\u0435\u043A\u0442\u0430, \u0447\u0442\u043E\u0431\u044B \u0441\u0430\u0439\u0442 \u0431\u044B\u043B \u0432\u0430\u043C \u043F\u043E \u043A\u0430\u0440\u043C\u0430\u043D\u0443!<br data-v-9d043aa4>\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C \u0441\u0432\u043E\u0438 \u043F\u0440\u043E\u0435\u043A\u0442\u044B \u043F\u043E\u0441\u043B\u0435 \u0441\u0434\u0430\u0447\u0438</h2></div><div class="offer__item" data-v-9d043aa4><div class="items__offers" data-v-9d043aa4><p data-v-9d043aa4>\u0414\u043E 20 \u0434\u043D\u0435\u0439</p><p data-v-9d043aa4>\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0441\u0430\u0439\u0442\u0430 \u043F\u043E\u0434 \u043A\u043B\u044E\u0447</p></div><div class="items__offers offers__center" data-v-9d043aa4><p data-v-9d043aa4>3 \u0433\u043E\u0434\u0430</p><p data-v-9d043aa4>\u0413\u0430\u0440\u0430\u043D\u0442\u0438\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442</p></div><div class="items__offers" data-v-9d043aa4><p data-v-9d043aa4>\u041E\u0442 150$</p><p data-v-9d043aa4>\u041F\u043E\u0434\u0431\u0435\u0440\u0451\u043C \u0431\u044E\u0434\u0436\u0435\u0442 \u043F\u043E\u0434 \u043C\u0430\u043B\u044B\u0435 \u043F\u0440\u043E\u0435\u043A\u0442\u044B</p></div></div><div class="offer__button" data-v-9d043aa4><button class="calc" data-v-9d043aa4><span data-v-9d043aa4>\u0420\u0430\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C</span><span data-v-9d043aa4>&gt;</span></button><button class="call__me" data-v-9d043aa4><span data-v-9d043aa4>\u0421\u0432\u044F\u0437\u0430\u0442\u044C\u0441\u044F \u0441 \u043D\u0430\u043C\u0438</span><span data-v-9d043aa4>&gt;</span></button></div></div><div class="offer__image" data-v-9d043aa4>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/PSD-4.png" }, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/offer.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["ssrRender", _sfc_ssrRender$9], ["__scopeId", "data-v-9d043aa4"]]);
const _sfc_main$c = {};
function _sfc_ssrRender$8(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "message" }, _attrs))} data-v-cfcf7b7a><button data-v-cfcf7b7a>\u041D\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u043D\u0430\u043C</button></div>`);
}
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/onlineMessage.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_1$2 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["ssrRender", _sfc_ssrRender$8], ["__scopeId", "data-v-cfcf7b7a"]]);
const _sfc_main$b = {
  __name: "title",
  __ssrInlineRender: true,
  props: {
    title: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<p${ssrRenderAttrs(mergeProps({ class: "title" }, _attrs))} data-v-b8fab296>${ssrInterpolate(__props.title)}</p>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ui-elements/title.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__scopeId", "data-v-b8fab296"]]);
const _sfc_main$a = {
  __name: "costItem",
  __ssrInlineRender: true,
  props: {
    timeDay: String,
    title: String,
    description: String,
    metaOne: String,
    metaTwo: String,
    metaThree: String,
    metaFour: String,
    metaFive: String,
    metaSix: String,
    cost: String,
    classCard: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "cards__cost" }, _attrs))} data-v-f46466c2><div data-v-f46466c2><div class="in__item__block" data-v-f46466c2><p data-v-f46466c2>${ssrInterpolate(__props.timeDay)}</p><p data-v-f46466c2>${ssrInterpolate(__props.title)}</p><p class="${ssrRenderClass(__props.classCard)}" data-v-f46466c2>${ssrInterpolate(__props.description)}</p></div><div class="meta" data-v-f46466c2><p data-v-f46466c2>${ssrInterpolate(__props.metaOne)}</p><p data-v-f46466c2>${ssrInterpolate(__props.metaTwo)}</p><p data-v-f46466c2>${ssrInterpolate(__props.metaThree)}</p><p data-v-f46466c2>${ssrInterpolate(__props.metaFour)}</p><p data-v-f46466c2>${ssrInterpolate(__props.metaFive)}</p><p data-v-f46466c2>${ssrInterpolate(__props.metaSix)}</p></div></div><div data-v-f46466c2><div class="cost" data-v-f46466c2><p data-v-f46466c2>\u0426\u0435\u043D\u0430</p><p data-v-f46466c2>\u043E\u0442 <span data-v-f46466c2>${ssrInterpolate(__props.cost)}</span></p></div><div class="button" data-v-f46466c2><button data-v-f46466c2>\u0420\u0430\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C</button></div></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ui-elements/costItem.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-f46466c2"]]);
const _sfc_main$9 = {};
function _sfc_ssrRender$7(_ctx, _push, _parent, _attrs) {
  const _component_UiElementsTitle = __nuxt_component_0;
  const _component_UiElementsCostItem = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "cost__dev" }, _attrs))} data-v-b9f6794d>`);
  _push(ssrRenderComponent(_component_UiElementsTitle, { title: "\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0438" }, null, _parent));
  _push(`<div class="cards" data-v-b9f6794d>`);
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    timeDay: "\u0421\u0440\u043E\u043A\u0438 5-10 \u0434\u043D\u0435\u0439",
    title: "\u041B\u044D\u043D\u0434\u0438\u043D\u0433",
    description: "\u0414\u043B\u044F \u043F\u0440\u043E\u0434\u0430\u0436 \u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0437\u0430\u044F\u0432\u043E\u043A",
    metaOne: "\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0434\u0438\u0437\u0430\u0439\u043D",
    metaTwo: "\u041C\u043E\u0431\u0438\u043B\u044C\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F",
    metaThree: "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0431\u043E\u0442\u0430 \u0432 \u0442\u0435\u043B\u0435\u0433\u0440\u0430\u043C",
    metaFour: "SEO \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F",
    cost: "150$"
  }, null, _parent));
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    timeDay: "\u0421\u0440\u043E\u043A\u0438 9-17 \u0434\u043D\u0435\u0439",
    title: "\u0418\u043D\u0442\u0435\u0440\u043D\u0435\u0442 \u043C\u0430\u0433\u0430\u0437\u0438\u043D",
    description: "\u0414\u043B\u044F \u043F\u0440\u043E\u0434\u0430\u0436 \u0442\u043E\u0432\u0430\u0440\u043E\u0432 \u0438\u043B\u0438 \u0443\u0441\u043B\u0443\u0433",
    metaOne: "\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0434\u0438\u0437\u0430\u0439\u043D",
    metaTwo: "\u041C\u043E\u0431\u0438\u043B\u044C\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F",
    metaThree: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 CRM",
    metaFour: "SEO \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F",
    metaFive: "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430",
    metaSix: "\u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0441 1\u0421, \u041C\u043E\u0439 \u0421\u043A\u043B\u0430\u0434, \u0412\u041A",
    cost: "230$"
  }, null, _parent));
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    timeDay: "\u0421\u0440\u043E\u043A\u0438 9-15 \u0434\u043D\u0435\u0439",
    title: "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0439",
    description: "\u0414\u043B\u044F \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 \u0435\u0435 \u0442\u043E\u0432\u0430\u0440\u0430\u0445 \u0438\u043B\u0438 \u0443\u0441\u043B\u0443\u0433\u0430\u0445",
    metaOne: "\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0434\u0438\u0437\u0430\u0439\u043D",
    metaTwo: "\u041C\u043E\u0431\u0438\u043B\u044C\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F",
    metaThree: "\u0410\u043D\u0430\u043B\u0438\u0437 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430 \u0438 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432",
    metaFour: "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B",
    metaFive: "SEO \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F",
    cost: "180$",
    classCard: "card__three"
  }, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/costDev.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["ssrRender", _sfc_ssrRender$7], ["__scopeId", "data-v-b9f6794d"]]);
const _sfc_main$8 = {};
function _sfc_ssrRender$6(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "social" }, _attrs))} data-v-b278754b><a href="" data-v-b278754b> Telegram </a> / <a href="" data-v-b278754b> Viber </a> / <a href="https://vk.com" data-v-b278754b> Vk </a></div>`);
}
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/social.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["ssrRender", _sfc_ssrRender$6], ["__scopeId", "data-v-b278754b"]]);
const _sfc_main$7 = {
  __name: "step",
  __ssrInlineRender: true,
  props: {
    buttonTitle: String,
    transitionText: String
  },
  setup(__props) {
    const show = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UiElementsIcons = __nuxt_component_1$4;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-84cb92f1><button class="transition__button" data-v-84cb92f1><p data-v-84cb92f1>${ssrInterpolate(__props.buttonTitle)}</p>`);
      _push(ssrRenderComponent(_component_UiElementsIcons, {
        "icon-name": "ic:outline-plus",
        "class-icon": { "plusIcon": unref(show) }
      }, null, _parent));
      _push(`</button>`);
      if (unref(show)) {
        _push(`<p class="transition__text" data-v-84cb92f1>${ssrInterpolate(__props.transitionText)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ui-elements/step.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-84cb92f1"]]);
const _sfc_main$6 = {};
function _sfc_ssrRender$5(_ctx, _push, _parent, _attrs) {
  const _component_UiElementsTitle = __nuxt_component_0;
  const _component_UiElementsStep = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "step" }, _attrs))} data-v-a0fd6733>`);
  _push(ssrRenderComponent(_component_UiElementsTitle, { title: "\u042D\u0442\u0430\u043F\u044B \u0438 \u043E\u043F\u043B\u0430\u0442\u0430" }, null, _parent));
  _push(`<hr data-v-a0fd6733>`);
  _push(ssrRenderComponent(_component_UiElementsStep, {
    "button-title": "\u0410\u043D\u0430\u043B\u0438\u0437 \u0438 \u0434\u0438\u0437\u0430\u0439\u043D",
    "transition-text": "\u041D\u0430 \u044D\u0442\u043E\u043C \u044D\u0442\u0430\u043F\u0435 \u043D\u0430\u0448\u0438 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442\u044B \u043F\u0440\u043E\u0432\u043E\u0434\u044F\u0442 \u0442\u0449\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0430\u043D\u0430\u043B\u0438\u0437 \u0432\u0430\u0448\u0435\u0439 \u0437\u0430\u0434\u0430\u0447\u0438 \u0438 \u0432\u0430\u0448\u0435\u0439 \u043E\u0442\u0440\u0430\u0441\u043B\u0438. \u041C\u044B \u0438\u0441\u0441\u043B\u0435\u0434\u0443\u0435\u043C \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432, \u0432\u044B\u044F\u0432\u043B\u044F\u0435\u043C \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0438 \u0446\u0435\u043B\u0438 \u0432\u0430\u0448\u0435\u0433\u043E \u043F\u0440\u043E\u0435\u043A\u0442\u0430. \u0417\u0430\u0442\u0435\u043C \u043D\u0430\u0448\u0438 \u0434\u0438\u0437\u0430\u0439\u043D\u0435\u0440\u044B \u0441\u043E\u0437\u0434\u0430\u044E\u0442 \u0434\u0435\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u0430\u043A\u0435\u0442\u044B \u0432 Figma, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0432\u043A\u043B\u044E\u0447\u0430\u044E\u0442 \u0432 \u0441\u0435\u0431\u044F \u0432\u0438\u0437\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u0438 \u0430\u0434\u0430\u043F\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440\u043E\u0432 \u0438 \u043C\u043E\u0431\u0438\u043B\u044C\u043D\u044B\u0445 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432. \u041E\u043F\u043B\u0430\u0442\u0430 \u0437\u0430 \u044D\u0442\u043E\u0442 \u044D\u0442\u0430\u043F \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 40% \u043F\u043E\u0441\u043B\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043C\u0430\u043A\u0435\u0442\u043E\u0432."
  }, null, _parent));
  _push(`<hr data-v-a0fd6733>`);
  _push(ssrRenderComponent(_component_UiElementsStep, {
    "button-title": "\u0421\u0431\u043E\u0440\u043A\u0430 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    "transition-text": "\u041D\u0430 \u0432\u0442\u043E\u0440\u043E\u043C \u044D\u0442\u0430\u043F\u0435 \u043C\u044B \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043D\u044B\u0439 \u0434\u0438\u0437\u0430\u0439\u043D \u043D\u0430 \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0443 Tilda \u0438 \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u043C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0443 \u0441\u0430\u0439\u0442\u0430. \u0417\u0434\u0435\u0441\u044C \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u0435 \u0443\u0434\u0435\u043B\u044F\u0435\u0442\u0441\u044F \u0434\u0435\u0442\u0430\u043B\u044F\u043C \u0438 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438. \u0412\u0430\u0448 \u0441\u0430\u0439\u0442 \u0443\u0436\u0435 \u043D\u0430 80% \u0433\u043E\u0442\u043E\u0432. \u041E\u043F\u043B\u0430\u0442\u0430 \u0437\u0430 \u044D\u0442\u043E\u0442 \u044D\u0442\u0430\u043F \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 40% \u043F\u043E\u0441\u043B\u0435 \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0439 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438."
  }, null, _parent));
  _push(`<hr data-v-a0fd6733>`);
  _push(ssrRenderComponent(_component_UiElementsStep, {
    "button-title": "\u0422\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0440\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u0435",
    "transition-text": "\u041D\u0430 \u0437\u0430\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u044D\u0442\u0430\u043F\u0435 \u043C\u044B \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u043C \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0440\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E \u043F\u0440\u043E\u0435\u043A\u0442\u0430. \u041C\u044B \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u043C \u043A\u0430\u0442\u0430\u043B\u043E\u0433, \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0435\u043C \u0434\u043E\u043C\u0435\u043D, \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u043C SEO-\u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044E \u0434\u043B\u044F \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F \u0432\u0438\u0434\u0438\u043C\u043E\u0441\u0442\u0438 \u0432\u0430\u0448\u0435\u0433\u043E \u0441\u0430\u0439\u0442\u0430 \u0432 \u043F\u043E\u0438\u0441\u043A\u043E\u0432\u044B\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445. \u0422\u0430\u043A\u0436\u0435 \u043C\u044B \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u0443\u0435\u043C \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B, \u0442\u0430\u043A\u0438\u0435 \u043A\u0430\u043A \u042F\u043D\u0434\u0435\u043A\u0441.\u0412\u0435\u0431\u043C\u0430\u0441\u0442\u0435\u0440 \u0438 Google Search Console. \u041F\u043E \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044E \u044D\u0442\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430, 20% \u043E\u043F\u043B\u0430\u0442\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u044B."
  }, null, _parent));
  _push(`<hr data-v-a0fd6733>`);
  _push(ssrRenderComponent(_component_UiElementsStep, {
    "button-title": "\u0413\u0430\u0440\u0430\u043D\u0442\u0438\u044F \u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
    "transition-text": "\u041F\u043E\u0441\u043B\u0435 \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0439 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u043D\u0430\u0448\u0435\u0439 \u0441\u0442\u0443\u0434\u0438\u0438, \u0432\u044B \u043F\u043E\u043B\u0443\u0447\u0430\u0435\u0442\u0435 24 \u043C\u0435\u0441\u044F\u0446\u0430 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0439\u043D\u043E\u0433\u043E \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F. \u042D\u0442\u043E \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442, \u0447\u0442\u043E \u043C\u044B \u043E\u0441\u0442\u0430\u043D\u0435\u043C\u0441\u044F \u043D\u0430 \u0441\u0432\u044F\u0437\u0438 \u0438 \u0433\u043E\u0442\u043E\u0432\u044B \u0440\u0435\u0448\u0430\u0442\u044C \u043B\u044E\u0431\u044B\u0435 \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B, \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u044E\u0449\u0438\u0435 \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0433\u043E\u0434\u0430. \u041D\u0430\u0448\u0430 \u0446\u0435\u043B\u044C - \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0442\u044C \u043D\u0430\u0434\u0435\u0436\u043D\u043E\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0441\u0430\u0439\u0442\u0430 \u0438 \u0432\u0430\u0448\u0435\u0433\u043E \u0431\u0438\u0437\u043D\u0435\u0441\u0430."
  }, null, _parent));
  _push(`<hr data-v-a0fd6733></div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/step.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$5], ["__scopeId", "data-v-a0fd6733"]]);
const _sfc_main$5 = {};
function _sfc_ssrRender$4(_ctx, _push, _parent, _attrs) {
  const _component_UiElementsTitle = __nuxt_component_0;
  const _component_NuxtImg = __nuxt_component_1$3;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "work" }, _attrs))} data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_UiElementsTitle, { title: "\u041D\u0430\u0448\u0438 \u0440\u0430\u0431\u043E\u0442\u044B" }, null, _parent));
  _push(`<div class="work__flex" data-v-2b4808d5><div class="work__row__one" data-v-2b4808d5><div class="fewho" data-v-2b4808d5><a href="https://%D0%A4%D0%B5%D1%85%D1%83.%D0%B1%D0%B5%D0%BB" data-v-2b4808d5><div class="fewho__img" data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/fewho.png" }, null, _parent));
  _push(`</div></a><p class="port__title" data-v-2b4808d5>\u041E\u041E\u041E \u201C\u0424\u0415\u0419\u0425\u0423\u201D</p><p class="port__desk" data-v-2b4808d5>\u0421\u0430\u0439\u0442 \u043F\u043E\u0441\u0442\u0430\u0432\u0449\u0438\u043A\u0430 \u043F\u0438\u0449\u0435\u0432\u043E\u0433\u043E \u0441\u044B\u0440\u044C\u044F \u0432 \u0420\u0411</p></div><div class="facture" data-v-2b4808d5><a href="https://factureproject.ru" data-v-2b4808d5><div class="facture__img" data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/facture.png" }, null, _parent));
  _push(`</div></a><p class="port__title" data-v-2b4808d5>Facture Project</p><p class="port__desk" data-v-2b4808d5>\u0421\u0430\u0439\u0442 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044F \u043C\u0435\u0431\u0435\u043B\u0438 \u0438\u0437 \u041C\u0440\u0430\u043C\u043E\u0440\u0430 \u0432 \u0420\u0424</p></div></div><div class="work__row__two" data-v-2b4808d5><div class="asai" data-v-2b4808d5><a href="https://Asaivapeshop.by" data-v-2b4808d5><div class="asai__img" data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/asai.png" }, null, _parent));
  _push(`</div></a><p class="port__title" data-v-2b4808d5>AsaiVapeShop</p><p class="port__desk" data-v-2b4808d5>\u0421\u0430\u0439\u0442 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442-\u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430 \u0432\u0435\u0439\u043F\u0448\u043E\u043F\u0430 \u0432 \u0420\u0411</p></div><div class="soen" data-v-2b4808d5><a href="https://Soen.su" data-v-2b4808d5><div class="soen__img" data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/soen.png" }, null, _parent));
  _push(`</div></a><p class="port__title" data-v-2b4808d5>SOEN</p><p class="port__desk" data-v-2b4808d5>\u0421\u0430\u0439\u0442 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442-\u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430 \u043A\u043E\u0441\u043C\u0435\u0442\u0438\u043A\u0438 \u0432 \u0420\u0424</p></div><div class="lafo" data-v-2b4808d5><a href="https://Laforme.su" data-v-2b4808d5><div class="lafo__img" data-v-2b4808d5>`);
  _push(ssrRenderComponent(_component_NuxtImg, { src: "image/lafo.png" }, null, _parent));
  _push(`</div></a><p class="port__title" data-v-2b4808d5>Laforme</p><p class="port__desk" data-v-2b4808d5>\u0421\u0430\u0439\u0442 \u0431\u0440\u0435\u043D\u0434\u0430 \u043E\u0434\u0435\u0436\u0434\u044B \u0438\u0437 \u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0431\u0443\u0440\u0433\u0430</p></div></div></div></div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/works.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$4], ["__scopeId", "data-v-2b4808d5"]]);
const _sfc_main$4 = {};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs) {
  const _component_UiElementsTitle = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "requ" }, _attrs))} data-v-cdb8b7ba>`);
  _push(ssrRenderComponent(_component_UiElementsTitle, { title: "\u0412\u0438\u0434\u0435\u043E \u043E\u0442\u0437\u044B\u0432\u044B" }, null, _parent));
  _push(`<div data-v-cdb8b7ba><div class="qqq" data-v-cdb8b7ba><div class="video__flex" data-v-cdb8b7ba><iframe width="560" height="315" src="https://www.youtube.com/shorts/AjZApYwWG88" srcdoc="&lt;style&gt;*{padding:0;margin:0;overflow:hidden}
                        html,body{height:100%}
                        img,span{position:absolute;width:100%;top:0;bottom:0;margin:auto}
                        span{height:1.5em;text-align:center;font:48px/1.5 sans-serif;color:white;text-shadow:0 0 0.5em black}
                        &lt;/style&gt;
                        &lt;a href=https://www.youtube.com/shorts/AjZApYwWG88?autoplay=1&gt;
                        &lt;img src=image/videoOne.png alt=&#39;Demo video&#39;&gt;
                        &lt;span&gt;\u25B6&lt;/span&gt;
                        &lt;/a&gt;" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen title="Demo video" data-v-cdb8b7ba>
                    </iframe><div class="video__text" data-v-cdb8b7ba><p data-v-cdb8b7ba>LaForme</p><p data-v-cdb8b7ba>\u041E\u0442\u0437\u044B\u0432 \u043E\u0442 \u0414\u0430\u043D\u0438\u043B\u044B, \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u0431\u0440\u0435\u043D\u0434\u0430 LaForme</p></div></div><div class="video__flex" data-v-cdb8b7ba><iframe width="560" height="315" src="https://www.youtube.com/embed/izvIofkLD4w?si=5IhTlsa4nQcktx8-" srcdoc="&lt;style&gt;*{padding:0;margin:0;overflow:hidden}
                        html,body{height:100%}
                        img,span{position:absolute;width:100%;top:0;bottom:0;margin:auto}
                        span{height:1.5em;text-align:center;font:48px/1.5 sans-serif;color:white;text-shadow:0 0 0.5em black}
                        &lt;/style&gt;
                        &lt;a href=https://www.youtube.com/embed/izvIofkLD4w?si=5IhTlsa4nQcktx8-?autoplay=1&gt;
                        &lt;img src=image/videoTwo.png alt=&#39;Demo video&#39;&gt;
                        &lt;span&gt;\u25B6&lt;/span&gt;
                        &lt;/a&gt;" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen title="Demo video" data-v-cdb8b7ba>
                    </iframe><div class="video__text" data-v-cdb8b7ba><p data-v-cdb8b7ba>AsaiVapeShop</p><p data-v-cdb8b7ba>\u041E\u0442\u0437\u044B\u0432 \u043E\u0442 \u0412\u043B\u0430\u0434\u0438\u0441\u043B\u0430\u0432\u0430, \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 Asaivapeshop</p></div></div></div></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/requ.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$3], ["__scopeId", "data-v-cdb8b7ba"]]);
const _sfc_main$3 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  const _component_UiElementsTitle = __nuxt_component_0;
  const _component_UiElementsCostItem = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "cost__seo" }, _attrs))} data-v-868dfde6>`);
  _push(ssrRenderComponent(_component_UiElementsTitle, { title: "\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F" }, null, _parent));
  _push(`<div class="costSeo__flex" data-v-868dfde6>`);
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    title: "SEO \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F",
    description: "SEO \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u043E\u0439\u0434\u0435\u0442 \u0434\u043B\u044F \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442 \u0432 \u0434\u043E\u043B\u0433\u043E\u0441\u0440\u043E\u0447\u043D\u043E\u0439 \u043F\u0435\u0440\u0441\u043F\u0435\u043A\u0442\u0438\u0432\u0435",
    metaOne: "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0441\u0435\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u044F\u0434\u0440\u0430",
    metaTwo: "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F \u0441\u0430\u0439\u0442\u0430",
    metaThree: "\u0412\u043D\u0435\u0448\u043D\u044F\u044F \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F \u0441\u0430\u0439\u0442\u0430",
    cost: "105$"
  }, null, _parent));
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    title: "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u043D\u043E\u0435",
    description: "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u043D\u043E\u0435 \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u043F\u043E\u0437\u0432\u043E\u043B\u0438\u0442 \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0438 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043F\u0435\u0440\u0432\u044B\u0435 \u0437\u0430\u044F\u0432\u043A\u0438 \u0441\u043F\u0443\u0441\u0442\u044F 3 \u0434\u043D\u044F",
    metaOne: "\u041F\u043E\u0434\u0431\u043E\u0440 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u0441\u043B\u043E\u0432",
    metaTwo: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0440\u0435\u043A\u043B\u0430\u043C\u043D\u044B\u0445 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0439",
    metaThree: "\u0410\u043D\u0430\u043B\u0438\u0437 \u0438 \u043F\u043E\u0434\u0431\u043E\u0440 \u0426\u0435\u043B\u0435\u0432\u043E\u0439 \u0430\u0443\u0434\u0438\u0442\u043E\u0440\u0438\u0438",
    metaFour: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0446\u0435\u043B\u0435\u0439 \u0438 \u043A\u043E\u043D\u0432\u0435\u0440\u0441\u0438\u0439",
    cost: "80$"
  }, null, _parent));
  _push(ssrRenderComponent(_component_UiElementsCostItem, {
    title: "\u041A\u043E\u043F\u0438\u0440\u0430\u0439\u0442\u0438\u043D\u0433",
    description: "\u0421\u043E\u0441\u0442\u0430\u0432\u0438\u043C \u0442\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u0432\u0430\u0448\u0435\u0433\u043E \u0441\u0430\u0439\u0442\u0430, \u0431\u043B\u043E\u0433\u0430, \u0441\u043E\u0446 \u0441\u0435\u0442\u0435\u0439. \u041F\u0438\u0448\u0435\u043C \u0442\u0435\u043A\u0441\u0442\u044B \u0434\u043B\u044F \u043B\u044E\u0431\u043E\u0439 \u043D\u0438\u0448\u0438",
    metaOne: "\u0410\u043D\u0430\u043B\u0438\u0437 \u0441\u0444\u0435\u0440\u044B \u0434\u0435\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 ( \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430 )",
    metaTwo: "\u041F\u043E\u0434\u0431\u043E\u0440 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u0441\u043B\u043E\u0432",
    metaThree: "\u041D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0435\u043A\u0441\u0442\u0430",
    cost: "10$"
  }, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/costSeo.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2], ["__scopeId", "data-v-868dfde6"]]);
const _sfc_main$2 = {
  __name: "description",
  __ssrInlineRender: true,
  setup(__props) {
    const shows = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UiElementsIcons = __nuxt_component_1$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "desc" }, _attrs))} data-v-390cfabf><div class="title__desc" data-v-390cfabf><h3 data-v-390cfabf>\u041F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0441\u0430\u0439\u0442\u043E\u0432 \u043F\u043E\u0434 \u043A\u043B\u044E\u0447</h3><p data-v-390cfabf>\u041F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0432 \u0441\u0435\u0442\u0438 - \u044D\u0442\u043E \u043D\u0435 \u043F\u0440\u043E\u0441\u0442\u043E \u0440\u0435\u043A\u043B\u0430\u043C\u043D\u044B\u0435 \u043A\u0430\u043C\u043F\u0430\u043D\u0438\u0438, \u0430 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0441\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430, \u043E\u0445\u0432\u0430\u0442\u044B\u0432\u0430\u044E\u0449\u0430\u044F \u0432\u0441\u0435 \u0430\u0441\u043F\u0435\u043A\u0442\u044B \u0432\u0435\u0431-\u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0438 \u043C\u0430\u0440\u043A\u0435\u0442\u0438\u043D\u0433\u0430:</p></div><div data-v-390cfabf><ul data-v-390cfabf><li data-v-390cfabf>UI/UX \u0414\u0438\u0437\u0430\u0439\u043D \u0434\u043B\u044F \u043F\u043E\u0432\u044B\u0448\u0435\u043D\u0438\u044F \u0443\u0434\u043E\u0431\u0441\u0442\u0432\u0430 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439.</li><li data-v-390cfabf>\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0441\u0430\u0439\u0442\u0430 \u0441 \u0432\u044B\u0441\u043E\u043A\u043E\u0439 \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u044C\u044E \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0438 \u0443\u0434\u043E\u0431\u043D\u044B\u043C \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u043E\u043C. \u041D\u0430\u0448 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439 \u0432\u043A\u043B\u044E\u0447\u0430\u0435\u0442 Figma \u0434\u043B\u044F \u0434\u0438\u0437\u0430\u0439\u043D\u0430 \u0438 Tilda \u0434\u043B\u044F \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0438.</li><li data-v-390cfabf>\u041F\u0440\u0438\u0432\u043B\u0435\u0447\u0435\u043D\u0438\u0435 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0430\u0443\u0434\u0438\u0442\u043E\u0440\u0438\u0438 \u0438\u0437 \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u0445 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u043E\u0432.</li><li data-v-390cfabf>SERM \u0434\u043B\u044F \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u044F \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438 \u0441\u0430\u0439\u0442\u0430 \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0435.</li><li data-v-390cfabf>\u0420\u0435\u0433\u0443\u043B\u044F\u0440\u043D\u044B\u0439 \u0430\u043D\u0430\u043B\u0438\u0437 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439, \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432 \u0438 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0440\u043E\u0432.</li></ul></div><div data-v-390cfabf><button data-v-390cfabf><p data-v-390cfabf>\u0427\u0438\u0442\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435</p>`);
      _push(ssrRenderComponent(_component_UiElementsIcons, {
        "icon-name": "ph:arrow-up-light",
        "class-icon": "arrow",
        "color-icon": "#1536DF",
        "size-width": "24px"
      }, null, _parent));
      _push(`</button>`);
      if (unref(shows)) {
        _push(`<div class="transition__text" data-v-390cfabf><h2 data-v-390cfabf>\u041F\u0440\u0435\u0438\u043C\u0443\u0449\u0435\u0441\u0442\u0432\u0430 \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u0432 \u0441\u0442\u0443\u0434\u0438\u0438 RudyStudio:</h2><ul data-v-390cfabf><p data-v-390cfabf>\u0413\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0432 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0435</p><li data-v-390cfabf>\u0411\u044B\u0441\u0442\u0440\u044B\u0439 \u0437\u0430\u043F\u0443\u0441\u043A.</li><li data-v-390cfabf>\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u043E\u0442 105$/\u043C\u0435\u0441\u044F\u0446.</li><p data-v-390cfabf>\u041C\u044B \u0438\u0434\u0435\u043C \u0432 \u043D\u043E\u0433\u0443 \u0441 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0435\u043C \u0446\u0438\u0444\u0440\u043E\u0432\u044B\u0445 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0439, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044F \u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u0441\u0430\u0439\u0442\u043E\u0432 \u0432 \u041C\u0438\u043D\u0441\u043A\u0435, \u0411\u0435\u043B\u0430\u0440\u0443\u0441\u0438, \u0420\u043E\u0441\u0441\u0438\u0438 \u0438 \u0441\u0442\u0440\u0430\u043D\u0430\u0445 \u0421\u041D\u0413.</p></ul><h2 data-v-390cfabf>\u041F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0442\u0435\u043C, \u043A\u0442\u043E \u0445\u043E\u0447\u0435\u0442:</h2><ul data-v-390cfabf><li data-v-390cfabf>\u041F\u043E\u0432\u044B\u0441\u0438\u0442\u044C \u043F\u043E\u0441\u0435\u0449\u0430\u0435\u043C\u043E\u0441\u0442\u044C \u0432 \u043F\u043E\u0438\u0441\u043A\u043E\u0432\u044B\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445.</li><li data-v-390cfabf>\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0446\u0435\u043B\u0435\u0432\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432.</li><li data-v-390cfabf>\u0423\u043B\u0443\u0447\u0448\u0438\u0442\u044C \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044E \u0432 \u043F\u043E\u0438\u0441\u043A\u043E\u0432\u043E\u043C \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u0435.</li><li data-v-390cfabf>\u0420\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0432 \u0434\u0440\u0443\u0433\u0438\u0445 \u0440\u0435\u0433\u0438\u043E\u043D\u0430\u0445 \u0438 \u0441\u0442\u0440\u0430\u043D\u0430\u0445.</li><li data-v-390cfabf>\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0437\u0430\u044F\u0432\u043E\u043A \u0438 \u043F\u0440\u043E\u0434\u0430\u0436.</li></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/description.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-390cfabf"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "forms" }, _attrs))} data-v-ea92bd25><div class="left" data-v-ea92bd25><h3 data-v-ea92bd25>\u0420\u0430\u0441\u0447\u0435\u0442<br data-v-ea92bd25>\u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u0438</h3><p data-v-ea92bd25>\u041C\u044B \u0441\u0432\u044F\u0436\u0435\u043C\u0441\u044F \u0441 \u0432\u0430\u043C\u0438 \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0438 20 \u043C\u0438\u043D\u0443\u0442</p></div><div data-v-ea92bd25></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/main/modal.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_9 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-ea92bd25"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_MainOffer = __nuxt_component_0$1;
  const _component_MainOnlineMessage = __nuxt_component_1$2;
  const _component_MainCostDev = __nuxt_component_2;
  const _component_MainSocial = __nuxt_component_3;
  const _component_MainStep = __nuxt_component_4;
  const _component_MainWorks = __nuxt_component_5;
  const _component_MainRequ = __nuxt_component_6;
  const _component_MainCostSeo = __nuxt_component_7;
  const _component_MainDescription = __nuxt_component_8;
  const _component_MainModal = __nuxt_component_9;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "main" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_MainOffer, null, null, _parent));
  _push(ssrRenderComponent(_component_MainOnlineMessage, null, null, _parent));
  _push(ssrRenderComponent(_component_MainCostDev, null, null, _parent));
  _push(ssrRenderComponent(_component_MainSocial, null, null, _parent));
  _push(ssrRenderComponent(_component_MainStep, null, null, _parent));
  _push(ssrRenderComponent(_component_MainWorks, null, null, _parent));
  _push(ssrRenderComponent(_component_MainRequ, null, null, _parent));
  _push(ssrRenderComponent(_component_MainCostSeo, null, null, _parent));
  _push(ssrRenderComponent(_component_MainDescription, null, null, _parent));
  _push(ssrRenderComponent(_component_MainModal, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-9dec86fa.mjs.map
