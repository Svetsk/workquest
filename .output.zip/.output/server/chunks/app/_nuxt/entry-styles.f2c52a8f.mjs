import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import 'vue/server-renderer';
import '@unhead/ssr';
import 'vue';
import 'unhead';
import '@unhead/shared';

const global = '@import url("https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap");@font-face{font-family:Museo Sans Cyrl\\ 100;src:url(' + buildAssetsURL("MuseoSansCyrl-100.54075098.ttf") + ")}@font-face{font-family:Museo Sans Cyrl\\ 500;src:url(" + buildAssetsURL("MuseoSansCyrl-500.9f623d8a.ttf") + ")}html{box-sizing:border-box;margin:0;overflow-x:hidden;padding:0}html body{font-family:Museo Sans Cyrl\\ 500;max-width:1460px;padding:0}.default,html body{margin:0 auto}li{list-style:none}a{color:#000;text-decoration:none}p{margin:0}";

const entryStyles_f2c52a8f = [global];

export { entryStyles_f2c52a8f as default };
//# sourceMappingURL=entry-styles.f2c52a8f.mjs.map
