import { _ as __nuxt_component_0$1 } from './nuxt-link-2717c1e6.mjs';
import { _ as __nuxt_component_1 } from './icons-addfcaba.mjs';
import { useSSRContext, resolveComponent, mergeProps, ref, withCtx, createTextVNode, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = {
  __name: "AddHeader",
  __ssrInlineRender: true,
  setup(__props) {
    const show = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_UiElementsIcons = __nuxt_component_1;
      _push(`<header${ssrRenderAttrs(_attrs)} data-v-23ce5a84><div class="logo" data-v-23ce5a84><p class="rudy" data-v-23ce5a84>Rudy</p><p class="studio" data-v-23ce5a84>Rudy Studio</p></div><nav class="desktop__menu" data-v-23ce5a84><ul class="desktop__menu__ul" data-v-23ce5a84><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u0421\u0430\u0439\u0442\u044B \u043F\u043E\u0434 \u043A\u043B\u044E\u0447</a></li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u041F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435</a></li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u041F\u043E\u0440\u0442\u0444\u043E\u043B\u0438\u043E</a></li><li data-v-23ce5a84>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "link",
        to: "/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0411\u043B\u043E\u0433`);
          } else {
            return [
              createTextVNode("\u0411\u043B\u043E\u0433")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u042D\u0442\u0430\u043F\u044B \u0438 \u043E\u043F\u043B\u0430\u0442\u0430</a></li></ul></nav><nav class="mobile__menu" data-v-23ce5a84>`);
      _push(ssrRenderComponent(_component_UiElementsIcons, {
        "icon-name": "ci:menu-alt-01",
        "class-icon": "burger",
        "color-icon": "#1536DF",
        "size-width": "24px",
        onClick: ($event) => show.value = !unref(show),
        key: "menu"
      }, null, _parent));
      if (unref(show)) {
        _push(`<ul class="mobile__menu__ul" data-v-23ce5a84><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u0421\u0430\u0439\u0442\u044B \u043F\u043E\u0434 \u043A\u043B\u044E\u0447</a></li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u041F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435</a></li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u041F\u043E\u0440\u0442\u0444\u043E\u043B\u0438\u043E</a></li><li data-v-23ce5a84>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "link",
          to: "/"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0411\u043B\u043E\u0433`);
            } else {
              return [
                createTextVNode("\u0411\u043B\u043E\u0433")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><li data-v-23ce5a84><a class="link" data-v-23ce5a84>\u042D\u0442\u0430\u043F\u044B \u0438 \u043E\u043F\u043B\u0430\u0442\u0430</a></li></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</nav><a href="" class="menu__button" data-v-23ce5a84><span data-v-23ce5a84>\u041F\u043E\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C</span>`);
      _push(ssrRenderComponent(_component_UiElementsIcons, {
        "icon-name": "ph:arrow-up-light",
        "class-icon": "arrow",
        "color-icon": "#1536DF",
        "size-width": "24px"
      }, null, _parent));
      _push(`</a></header>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ui/AddHeader.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-23ce5a84"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_UiAddHeader = __nuxt_component_0;
  const _component_UiAddFooter = resolveComponent("UiAddFooter");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "default" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_UiAddHeader, null, null, _parent));
  _push(`<main>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_UiAddFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-9bc9ed67.mjs.map
